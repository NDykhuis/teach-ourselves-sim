import simulator as sim
sim.run(saveresults=False)
